#ifndef R_VERSION_H
#define R_VERSION_H 1
#define R_MESON_VERSION "0.61.99"
#define R2_VERSION_MAJOR 5
#define R2_VERSION_MINOR 7
#define R2_VERSION_PATCH 4
#define R2_VERSION_NUMBER 50704
#define R2_VERSION_COMMIT 1
#define R2_VERSION "5.7.4"
#define R2_GITTAP "5.7.4"
#define R2_GITTIP "5bc3bf4e6c327121c8f82f20a603382cbba07dbb"
#define R2_BIRTH "Wed 07/06/2022__22:49:07.33"
#endif
