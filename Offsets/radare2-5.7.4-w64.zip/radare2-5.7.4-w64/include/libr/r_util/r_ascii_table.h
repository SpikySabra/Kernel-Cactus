/* radare - LGPL - Copyright 2008-2016 - pancake, r00tus3r */

#ifndef R_ASCII_TABLE_H
#define R_ASCII_TABLE_H

#ifdef __cplusplus
extern "C" {
#endif

R_API const char *ret_ascii_table(void);

#ifdef __cplusplus
}
#endif

#endif
